package com.example.android.camera2basic;

import android.support.v4.app.FragmentManager;

public interface AccelerometerListener {


    public void onAccelerationChanged(float x, float y, float z);

    public void onShake(float force);

}
